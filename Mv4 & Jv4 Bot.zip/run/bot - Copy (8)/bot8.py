# ==== tor_bot.py (optimized) ====
import threading
import socket
import time
import os
import random
import sys
import requests
import tempfile
import shutil
import json
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import *
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from fake_useragent import UserAgent
import job  # External job file

# Tor settings
TOR_CONTROL_PORT = 9121
TOR_PROXY_PORT = 9120
TOR_PASSWORD = "bot"
ip_change_count = 0
seen_ips = set()
MAX_PING_MS = 2000  # Maximum allowed latency in milliseconds
PING_TEST_URL = "http://www.google.com"  # Fast and reliable test URL
MAX_ATTEMPTS = 10  # Max attempts to get a good IP

def get_current_ip():
    try:
        print("\U0001F310 Checking IP...")
        ip = requests.get(
            "https://api.ipify.org",
            proxies={'http': f'socks5h://127.0.0.1:{TOR_PROXY_PORT}', 
                     'https': f'socks5h://127.0.0.1:{TOR_PROXY_PORT}'},
            timeout=10
        ).text.strip()
        print(f"✅ Current IP: {ip}")
        return ip
    except Exception as e:
        print(f"❌ IP fetch error: {str(e)[:50]}")
        return "❌ (Failed to fetch IP)"

def measure_ping():
    """Measure latency through Tor proxy in milliseconds"""
    try:
        start_time = time.time()
        requests.head(
            PING_TEST_URL,
            proxies={'http': f'socks5h://127.0.0.1:{TOR_PROXY_PORT}', 
                     'https': f'socks5h://127.0.0.1:{TOR_PROXY_PORT}'},
            timeout=5
        )
        ping_time = (time.time() - start_time) * 1000  # Convert to ms
        return ping_time
    except Exception as e:
        print(f"❌ Ping test failed: {str(e)[:50]}")
        return float('inf')  # Return infinity if failed

def new_tor_ip():
    global ip_change_count, seen_ips
    attempt = 0
    
    while attempt < MAX_ATTEMPTS:
        try:
            print("\U0001F501 Getting new Tor IP...")
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(10)
                s.connect(("127.0.0.1", TOR_CONTROL_PORT))
                s.send(f'AUTHENTICATE "{TOR_PASSWORD}"\r\n'.encode())
                response = s.recv(1024)
                
                if b"250 OK" in response:
                    s.send(b'SIGNAL NEWNYM\r\n')
                    s.recv(1024)
                    time.sleep(5)  # Allow circuit rebuild time
                    
                    new_ip = get_current_ip()
                    if new_ip == "❌ (Failed to fetch IP)":
                        attempt += 1
                        print(f"⚠️ IP check failed, retrying ({attempt}/{MAX_ATTEMPTS})")
                        continue
                    
                    # Skip duplicate IPs immediately
                    if new_ip in seen_ips:
                        print(f"⚠️ Duplicate IP skipped: {new_ip}")
                        attempt += 1
                        continue
                    
                    # Measure IP latency
                    ping_time = measure_ping()
                    
                    # Accept only fast and unique IPs
                    if ping_time <= MAX_PING_MS:
                        seen_ips.add(new_ip)
                        ip_change_count += 1
                        print(f"🔄 [IP changed] {new_ip} | Ping: {ping_time:.0f}ms | Unique IPs: {ip_change_count}")
                        return new_ip
                    else:
                        print(f"⚠️ Slow IP skipped: {new_ip} ({ping_time:.0f}ms > {MAX_PING_MS}ms)")
                        seen_ips.add(new_ip)  # Remember slow IPs
                else:
                    print(f"❌ Tor authentication failed: {response.decode()[:50]}")
        except Exception as e:
            print(f"❌ Tor IP change error: {str(e)[:50]}")
        
        attempt += 1
        if attempt < MAX_ATTEMPTS:
            countdown(5, f"Retrying IP change ({attempt}/{MAX_ATTEMPTS})")
    
    print("❌ Failed to get suitable IP after multiple attempts")
    return None

def countdown(sec, msg="Waiting"):
    for s in range(sec, 0, -1):
        sys.stdout.write(f"\r⏳ {msg}: {s}s... ")
        sys.stdout.flush()
        time.sleep(1)
    print("\r" + " " * 50 + "\r", end='')

def init_driver(user_agent):
    print("🧩 Initializing undetected Chrome...")
    try:
        # Create temp profile
        profile_path = tempfile.mkdtemp()
        
        # Setup Chrome options
        options = uc.ChromeOptions()
        options.add_argument(f'--user-data-dir={profile_path}')
        options.add_argument(f'--user-agent={user_agent}')
        options.add_argument(f'--proxy-server=socks5://127.0.0.1:{TOR_PROXY_PORT}')
        options.add_argument('--proxy-dns')
        options.add_argument('--disable-blink-features=AutomationControlled')
        options.add_argument('--no-first-run')
        options.add_argument('--no-service-autorun')
        options.add_argument('--no-default-browser-check')
        options.add_argument('--disable-web-security')
        options.add_argument('--allow-running-insecure-content')
        options.add_argument('--start-maximized')  # Ensure browser starts maximized
        
        # WebRTC and fingerprint protection
        webrtc_prefs = {
            "webrtc.ip_handling_policy": "disable_non_proxied_udp",
            "webrtc.multiple_routes_enabled": False,
            "webrtc.nonproxied_udp_enabled": False
        }
        options.add_experimental_option("prefs", webrtc_prefs)

        # Initialize undetected Chrome
        driver = uc.Chrome(
            options=options,
            headless=False,
            use_subprocess=True,
            suppress_welcome=True
        )
        
        # Maximize window for full-screen appearance
        driver.maximize_window()
        time.sleep(1)  # Allow time for window to maximize
        
        # Execute anti-detection scripts
        driver.execute_script("""
            // Mask webdriver flag
            Object.defineProperty(navigator, 'webdriver', {
                get: () => undefined
            });

            // Spoof chrome runtime properties
            window.navigator.chrome = {
                app: { isInstalled: false },
                webstore: { onInstallStageChanged: {}, onDownloadProgress: {} },
                runtime: {
                    PlatformOs: { MAC: 'mac', WIN: 'win', ANDROID: 'android', CROS: 'cros', LINUX: 'linux', OPENBSD: 'openbsd' },
                    PlatformArch: { ARM: 'arm', X86_32: 'x86-32', X86_64: 'x86-64' },
                    PlatformNaclArch: { ARM: 'arm', X86_32: 'x86-32', X86_64: 'x86-64' },
                    RequestUpdateCheckStatus: { THROTTLED: 'throttled', NO_UPDATE: 'no_update', UPDATE_AVAILABLE: 'update_available' },
                    OnInstalledReason: { INSTALL: 'install', UPDATE: 'update', CHROME_UPDATE: 'chrome_update', SHARED_MODULE_UPDATE: 'shared_module_update' },
                    OnRestartRequiredReason: { APP_UPDATE: 'app_update', OS_UPDATE: 'os_update', PERIODIC: 'periodic' }
                }
            };

            // Battery API spoofing
            const originalGetBattery = navigator.getBattery;
            navigator.getBattery = async () => {
                const battery = await originalGetBattery();
                Object.defineProperty(battery, 'charging', { value: true });
                Object.defineProperty(battery, 'chargingTime', { value: 0 });
                Object.defineProperty(battery, 'dischargingTime', { value: Infinity });
                Object.defineProperty(battery, 'level', { value: 0.85 });
                return battery;
            };

            // ========= ADVANCED FINGERPRINT PROTECTION =========
            // WebGL vendor/renderer spoofing
            const getParameterProxy = new Proxy(WebGLRenderingContext.prototype.getParameter, {
                apply: function(target, thisArg, args) {
                    const param = args[0];
                    // UNMASKED_VENDOR_WEBGL
                    if (param === 37445) return 'Google Inc. (NVIDIA)';
                    // UNMASKED_RENDERER_WEBGL
                    if (param === 37446) return 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3080 Direct3D11 vs_5_0 ps_5_0, D3D11)';
                    // Debug renderer info
                    if (param === 37447) return 'WebKit';
                    return target.apply(thisArg, args);
                }
            });
            WebGLRenderingContext.prototype.getParameter = getParameterProxy;

            // WebGL extension spoofing
            const getSupportedExtensions = function() {
                return [
                    'ANGLE_instanced_arrays', 'OES_element_index_uint', 'OES_standard_derivatives',
                    'OES_texture_float', 'OES_texture_float_linear', 'WEBGL_color_buffer_float',
                    'WEBGL_compressed_texture_s3tc', 'WEBGL_debug_renderer_info', 'WEBGL_debug_shaders',
                    'WEBGL_depth_texture', 'WEBGL_draw_buffers', 'EXT_blend_minmax', 'EXT_frag_depth',
                    'EXT_shader_texture_lod', 'EXT_sRGB', 'EXT_texture_filter_anisotropic'
                ];
            };
            WebGLRenderingContext.prototype.getSupportedExtensions = getSupportedExtensions;

            // Canvas fingerprint protection
            const originalToDataURL = HTMLCanvasElement.prototype.toDataURL;
            HTMLCanvasElement.prototype.toDataURL = function(type, encoderOptions) {
                const ctx = this.getContext('2d');
                if (ctx) {
                    ctx.fillStyle = 'rgb(128, 128, 128)';
                    ctx.fillRect(0, 0, this.width, this.height);
                    ctx.fillStyle = 'rgb(0, 0, 0)';
                    ctx.font = '20px Arial';
                    ctx.fillText('Protected Canvas', 10, 50);
                }
                return originalToDataURL.call(this, type, encoderOptions);
            };

            // AudioContext fingerprint protection
            if (typeof AudioContext !== 'undefined') {
                const originalCreateOscillator = AudioContext.prototype.createOscillator;
                AudioContext.prototype.createOscillator = function() {
                    const oscillator = originalCreateOscillator.call(this);
                    oscillator.frequency.value = 440;
                    return oscillator;
                };
            }

            // Navigator property overrides
            Object.defineProperties(navigator, {
                hardwareConcurrency: { value: 4, configurable: false },
                deviceMemory: { value: 4, configurable: false },
                maxTouchPoints: { value: 0, configurable: false },
                plugins: {
                    value: [{
                        name: 'Chrome PDF Viewer',
                        filename: 'internal-pdf-viewer',
                        description: 'Portable Document Format'
                    }],
                    configurable: false
                },
                languages: { value: ['en-US', 'en'], configurable: true },
                platform: {
                    get: function() {
                        const ua = navigator.userAgent;
                        if (ua.includes('Windows')) return 'Win32';
                        if (ua.includes('Mac')) return 'MacIntel';
                        if (ua.includes('Linux')) return 'Linux x86_64';
                        return 'Win32';
                    },
                    configurable: true
                }
            });

            // Font fingerprint protection
            const originalMeasureText = CanvasRenderingContext2D.prototype.measureText;
            CanvasRenderingContext2D.prototype.measureText = function(text) {
                const metrics = originalMeasureText.call(this, text);
                metrics.width = Math.round(metrics.width);
                return metrics;
            };
        """)
        
        print("🛡️ Comprehensive fingerprint protection applied")
        return driver, profile_path
    except Exception as e:
        print(f"WebDriver error: {e}")
        return None, None

def close_driver(driver, profile_path):
    try:
        driver.quit()
    except:
        pass
    try:
        shutil.rmtree(profile_path, ignore_errors=True)
    except:
        pass

def main_bot_loop():
    driver = None
    profile_path = None
    
    while True:
        try:
            # Get new Tor IP
            new_ip = new_tor_ip()
            if new_ip is None:
                countdown(30, "Restarting after IP failure")
                continue

            # Get random user agent
            ua = UserAgent()
            user_agent = ua.random
            print(f"🆔 User Agent: {user_agent}")

            # Initialize driver
            driver, profile_path = init_driver(user_agent)
            if driver is None:
                countdown(30, "Restarting after driver failure")
                continue

            # Run job from external file
            pages = random.randint(4, 7)
            print(f"🚀 Starting new session ({pages} pages)")
            success = job.run_job(driver, pages)

            # Post-session cleanup
            close_driver(driver, profile_path)
            driver = None
            profile_path = None
            
            if success:
                countdown(random.randint(120, 300), "Waiting between sessions")
            else:
                countdown(random.randint(10, 30), "Restarting after job failure")

        except Exception as e:
            print(f"💥 Critical error: {e}")
            if driver:
                close_driver(driver, profile_path)
            countdown(30, "Recovering from crash")

if __name__ == "__main__":
    print("🔥 Undetectable Tor Bot v3.2 Starting...")
    print("✅ শুধু ভালো (fast) IP ব্যবহার করা হবে")
    print("✅ যে IP স্লো/পিং বেশি — তা অটো বাদ দিয়ে নতুন IP আনা হবে")
    print("✅ একই IP যেন বারবার না আসে — একবারই ব্যবহার হবে (unique only)")
    main_bot_loop()